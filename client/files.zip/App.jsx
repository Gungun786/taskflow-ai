import { useState } from "react";
import Dashboard from "./pages/Dashboard";
import TasksPage from "./pages/TasksPage";
import AIAgent from "./components/AIAgent";
import Sidebar from "./components/Sidebar";
import "./index.css";

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [agentOpen, setAgentOpen] = useState(false);

  return (
    <div className="app-shell">
      <Sidebar page={page} setPage={setPage} onAgentOpen={() => setAgentOpen(true)} />
      <main className="main-content">
        {page === "dashboard" && <Dashboard />}
        {page === "tasks" && <TasksPage />}
      </main>
      <AIAgent open={agentOpen} onClose={() => setAgentOpen(false)} />
    </div>
  );
}
